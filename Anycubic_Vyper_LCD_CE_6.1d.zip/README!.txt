﻿Anycubic Vyper

1. Flash screen
2. Flash mainboard
3. Reset
4. Press SETUP -> Restore Factory...
5. Reset
6. Press SETUP -> Restore Factory... one more time
7. Reset
8. Setting up and calibrate everything you can
9. Reset
10. Print


